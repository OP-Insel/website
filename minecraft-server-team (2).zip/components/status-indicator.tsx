import { cn } from "@/lib/utils"
import { CheckCircle, XCircle } from "lucide-react"

interface StatusIndicatorProps {
  status: boolean
  activeText?: string
  inactiveText?: string
  className?: string
}

export function StatusIndicator({
  status,
  activeText = "Aktiv",
  inactiveText = "Inaktiv",
  className,
}: StatusIndicatorProps) {
  return (
    <div className={cn("flex items-center", className)}>
      {status ? (
        <>
          <CheckCircle className="h-4 w-4 text-green-600 mr-1" />
          <span className="text-green-600 font-medium">{activeText}</span>
        </>
      ) : (
        <>
          <XCircle className="h-4 w-4 text-red-500 mr-1" />
          <span className="text-red-500 font-medium">{inactiveText}</span>
        </>
      )}
    </div>
  )
}

