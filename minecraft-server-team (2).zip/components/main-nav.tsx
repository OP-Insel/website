"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { MoonIcon, SunIcon, Menu, X, LogOut } from "lucide-react"
import { useTheme } from "next-themes"
import { useRouter } from "next/navigation"
import { useToast } from "@/hooks/use-toast"
import { NotificationIndicator } from "@/components/notification-indicator"
import { PointsDisplay } from "@/components/points-display"

interface MainNavProps {
  className?: string
}

export function MainNav({ className }: MainNavProps) {
  const pathname = usePathname()
  const { setTheme } = useTheme()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    // Get current user from localStorage
    const currentUser = localStorage.getItem("currentUser")
    if (currentUser) {
      setUser(JSON.parse(currentUser))
    }
  }, [])

  const handleLogout = () => {
    // Add to activity log
    if (user) {
      const activityLog = JSON.parse(localStorage.getItem("activityLog") || "[]")
      activityLog.unshift({
        id: Date.now().toString(),
        type: "user_logout",
        userId: user.id,
        username: user.username,
        timestamp: new Date().toISOString(),
        details: "User logged out",
      })
      localStorage.setItem("activityLog", JSON.stringify(activityLog))
    }

    localStorage.removeItem("currentUser")
    toast({
      title: "Erfolg",
      description: "Du wurdest abgemeldet.",
    })
    router.push("/")
  }

  const hasPermission = (permission: string) => {
    if (!user) return false

    // Check if user has the specific permission
    if (user.permissions && user.permissions.includes(permission)) {
      return true
    }

    // Check if user's role has the permission
    const roles = JSON.parse(localStorage.getItem("roles") || "[]")
    const userRole = roles.find((role: any) => role.id === user.role)

    return userRole && userRole.permissions && userRole.permissions.includes(permission)
  }

  const isOwnerOrCoOwner = user?.role === "owner" || user?.role === "co-owner"

  // Aktualisiere die navItems, um sicherzustellen, dass das Owner Panel korrekt angezeigt wird
  const navItems = [
    { href: "/dashboard", label: "Dashboard", permission: null },
    { href: "/users", label: "Benutzer", permission: null },
    { href: "/tasks", label: "Aufgaben", permission: null },
    { href: "/stories", label: "Geschichten", permission: null },
    { href: "/content", label: "Inhalte", permission: "create_content" },
    { href: "/profile", label: "Profil", permission: null },
    { href: "/admin", label: "Admin", permission: "view_admin" },
    { href: "/owner-panel", label: "Owner Panel", permission: null, ownerOnly: true },
  ]

  // Aktualisiere die Filterung, um sicherzustellen, dass das Owner Panel nur für Owner und Co-Owner angezeigt wird
  const filteredNavItems = navItems.filter(
    (item) =>
      (item.permission === null || hasPermission(item.permission as string)) && (!item.ownerOnly || isOwnerOrCoOwner),
  )

  return (
    <div className="border-b">
      <div className="flex h-16 items-center px-4">
        <div className="md:hidden mr-2">
          <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>

        <Link href="/dashboard" className="mr-6 flex items-center space-x-2">
          <span className="hidden md:inline-block font-bold text-xl">OP-Insel Team</span>
        </Link>

        <nav className={cn("hidden md:flex items-center space-x-4 lg:space-x-6", className)}>
          {filteredNavItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                pathname === item.href ? "text-foreground" : "text-muted-foreground",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="fixed inset-0 top-16 z-50 bg-background animate-in md:hidden">
            <nav className="flex flex-col p-4 space-y-4">
              {filteredNavItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-primary p-2 rounded-md",
                    pathname === item.href ? "bg-secondary text-foreground" : "text-muted-foreground",
                  )}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <Button variant="destructive" className="mt-4" onClick={handleLogout}>
                <LogOut className="mr-2 h-4 w-4" />
                Abmelden
              </Button>
            </nav>
          </div>
        )}

        <div className="ml-auto flex items-center space-x-4">
          {user && (
            <>
              <PointsDisplay points={user.points || 0} showTrend className="hidden md:flex" />
              <span className="text-sm hidden md:block">Hallo, {user.username}!</span>
            </>
          )}
          <NotificationIndicator />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <SunIcon className="h-[1.2rem] w-[1.2rem] rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
                <MoonIcon className="absolute h-[1.2rem] w-[1.2rem] rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
                <span className="sr-only">Theme wechseln</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setTheme("light")}>Hell</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("dark")}>Dunkel</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("system")}>System</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="ghost" size="icon" onClick={handleLogout}>
            <LogOut className="h-[1.2rem] w-[1.2rem]" />
            <span className="sr-only">Abmelden</span>
          </Button>
        </div>
      </div>
    </div>
  )
}

