"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Separator } from "@/components/ui/separator"
import { useServerData } from "@/components/server-data-provider"
import { RefreshCw, Server, Users, Clock, MemoryStickIcon as Memory, Activity, AlertCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function EnhancedServerStatus() {
  const { stats, loading, error, refreshData } = useServerData()
  const [refreshing, setRefreshing] = useState(false)

  const handleRefresh = async () => {
    setRefreshing(true)
    await refreshData()
    setTimeout(() => setRefreshing(false), 1000)
  }

  // Aktualisiere die Anzeige für den Fall, dass der Server offline ist
  const formatUptime = (seconds: number): string => {
    if (seconds === 0) return "N/A"

    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)

    return `${days}d ${hours}h ${minutes}m`
  }

  // Formatiere Speichernutzung in MB oder GB
  const formatMemory = (mb: number) => {
    if (mb >= 1024) {
      return `${(mb / 1024).toFixed(1)} GB`
    }
    return `${Math.round(mb)} MB`
  }

  if (loading && !stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Server className="mr-2 h-5 w-5" />
            <Skeleton className="h-6 w-40" />
          </CardTitle>
          <CardDescription>
            <Skeleton className="h-4 w-60" />
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-40 w-full" />
        </CardContent>
      </Card>
    )
  }

  // Füge eine bessere Fehlerbehandlung hinzu
  if (error || !stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Server Status</CardTitle>
          <CardDescription>Status von OPInsel.de</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Fehler</AlertTitle>
            <AlertDescription>{error || "Serverdaten konnten nicht abgerufen werden"}</AlertDescription>
          </Alert>
          <div className="mt-4 flex justify-center">
            <Button onClick={handleRefresh} disabled={refreshing}>
              {refreshing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Aktualisiere...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Erneut versuchen
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Verbessere die Anzeige für den Fall, dass der Server offline ist
  if (!stats.online) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <div>
            <CardTitle className="flex items-center">
              <Server className="mr-2 h-5 w-5" />
              OPInsel.de
              <Badge variant="destructive" className="ml-2">
                Offline
              </Badge>
            </CardTitle>
            <CardDescription>Zuletzt aktualisiert: {stats.lastUpdated.toLocaleTimeString()}</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={refreshing}>
            {refreshing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          </Button>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <AlertCircle className="mx-auto h-12 w-12 text-destructive opacity-80" />
            <h3 className="mt-4 text-lg font-medium">Server ist offline</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Der Minecraft-Server OPInsel.de ist derzeit nicht erreichbar.
            </p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="flex items-center">
              <Server className="mr-2 h-5 w-5" />
              OPInsel.de
              <Badge variant={stats.online ? "success" : "destructive"} className="ml-2">
                {stats.online ? "Online" : "Offline"}
              </Badge>
            </CardTitle>
            <CardDescription>
              Version: {stats.version} • Zuletzt aktualisiert: {stats.lastUpdated.toLocaleTimeString()}
            </CardDescription>
          </div>
          <Button
            variant="outline"
            size="icon"
            onClick={handleRefresh}
            disabled={refreshing}
            className={refreshing ? "animate-spin" : ""}
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Server-Statistiken */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="flex flex-col space-y-1">
            <span className="text-sm font-medium flex items-center">
              <Users className="mr-1 h-4 w-4" /> Spieler
            </span>
            <span className="text-2xl font-bold">
              {stats.players.online}/{stats.players.max}
            </span>
            <Progress value={(stats.players.online / stats.players.max) * 100} className="h-2" />
          </div>

          <div className="flex flex-col space-y-1">
            <span className="text-sm font-medium flex items-center">
              <Activity className="mr-1 h-4 w-4" /> TPS
            </span>
            <span className="text-2xl font-bold">{stats.tps.toFixed(1)}</span>
            <Progress
              value={(stats.tps / 20) * 100}
              className="h-2"
              variant={stats.tps >= 18 ? "default" : stats.tps >= 15 ? "warning" : "destructive"}
            />
          </div>

          <div className="flex flex-col space-y-1">
            <span className="text-sm font-medium flex items-center">
              <Memory className="mr-1 h-4 w-4" /> RAM
            </span>
            <span className="text-2xl font-bold">
              {formatMemory(stats.memoryUsage)}/{formatMemory(stats.memoryMax)}
            </span>
            <Progress value={(stats.memoryUsage / stats.memoryMax) * 100} className="h-2" />
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Clock className="h-4 w-4" />
          <span className="text-sm">Uptime: {formatUptime(stats.uptime)}</span>
        </div>

        <Separator />

        {/* Spielerliste */}
        <div>
          <h3 className="font-medium mb-3">Online Spieler ({stats.players.online})</h3>
          {stats.players.online === 0 ? (
            <p className="text-sm text-muted-foreground">Keine Spieler online</p>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {stats.players.list.map((player) => (
                <div key={player} className="flex items-center space-x-2 p-2 rounded-md bg-secondary/50">
                  <Avatar>
                    <AvatarImage src={`https://mc-heads.net/avatar/${player}/64`} alt={player} />
                    <AvatarFallback>{player.substring(0, 2)}</AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium truncate">{player}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

