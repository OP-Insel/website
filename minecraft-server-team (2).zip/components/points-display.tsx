import { ArrowDown, ArrowUp, Minus } from "lucide-react"
import { cn } from "@/lib/utils"

interface PointsDisplayProps {
  points: number
  size?: "sm" | "md" | "lg"
  showTrend?: boolean
  previousPoints?: number
  className?: string
}

export function PointsDisplay({
  points,
  size = "md",
  showTrend = false,
  previousPoints,
  className,
}: PointsDisplayProps) {
  const sizeClasses = {
    sm: "text-sm",
    md: "text-base",
    lg: "text-xl font-bold",
  }

  const pointsDiff = previousPoints !== undefined ? points - previousPoints : 0

  return (
    <div className={cn("flex items-center", className)}>
      <span
        className={cn(
          "font-medium",
          sizeClasses[size],
          points > 0 ? "text-green-600" : points < 0 ? "text-red-500" : "text-gray-500",
        )}
      >
        {points} Punkte
      </span>

      {showTrend && previousPoints !== undefined && (
        <div className="ml-2 flex items-center">
          {pointsDiff > 0 ? (
            <ArrowUp className="h-3 w-3 text-green-600" />
          ) : pointsDiff < 0 ? (
            <ArrowDown className="h-3 w-3 text-red-500" />
          ) : (
            <Minus className="h-3 w-3 text-gray-400" />
          )}
          <span
            className={cn(
              "text-xs ml-1",
              pointsDiff > 0 ? "text-green-600" : pointsDiff < 0 ? "text-red-500" : "text-gray-400",
            )}
          >
            {Math.abs(pointsDiff)}
          </span>
        </div>
      )}
    </div>
  )
}

