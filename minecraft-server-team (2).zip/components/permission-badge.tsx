"use client"

import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface PermissionBadgeProps {
  permission: string
  hasPermission: boolean
  onClick?: () => void
  className?: string
}

export function PermissionBadge({ permission, hasPermission, onClick, className }: PermissionBadgeProps) {
  return (
    <Badge
      variant={hasPermission ? "default" : "outline"}
      className={cn(
        hasPermission
          ? "bg-green-600 hover:bg-green-700"
          : "text-red-500 border-red-500 hover:bg-red-100 hover:text-red-600",
        onClick ? "cursor-pointer" : "",
        className,
      )}
      onClick={onClick}
    >
      {permission}
    </Badge>
  )
}

