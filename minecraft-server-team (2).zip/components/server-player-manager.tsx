"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { useServerData } from "@/components/server-data-provider"
import { Search, Ban, UserMinus, Shield, MessageSquare, Crown } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"

interface PlayerAction {
  type: "kick" | "ban" | "op" | "message"
  player: string
  reason?: string
}

export function ServerPlayerManager() {
  const { stats } = useServerData()
  const { toast } = useToast()
  const [searchQuery, setSearchQuery] = useState("")
  const [actionDialog, setActionDialog] = useState<{
    open: boolean
    action: PlayerAction | null
  }>({
    open: false,
    action: null,
  })
  const [reason, setReason] = useState("")
  const [message, setMessage] = useState("")

  // Simuliere zusätzliche Spielerdaten
  const playerData =
    stats?.players.list.map((player) => ({
      name: player,
      ip: `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
      isOp: ["edgargamer1781", "Notch"].includes(player),
      playTime: Math.floor(Math.random() * 10000),
      lastLogin: new Date(Date.now() - Math.floor(Math.random() * 86400000)),
    })) || []

  const filteredPlayers = playerData.filter((player) => player.name.toLowerCase().includes(searchQuery.toLowerCase()))

  const handleAction = (type: "kick" | "ban" | "op" | "message", player: string) => {
    setActionDialog({
      open: true,
      action: { type, player },
    })

    setReason("")
    setMessage("")
  }

  const executeAction = () => {
    if (!actionDialog.action) return

    const { type, player } = actionDialog.action

    // Simuliere Serveraktion
    setTimeout(() => {
      let successMessage = ""

      switch (type) {
        case "kick":
          successMessage = `Spieler ${player} wurde vom Server gekickt.`
          break
        case "ban":
          successMessage = `Spieler ${player} wurde vom Server gebannt.`
          break
        case "op":
          successMessage = `Spieler ${player} wurde zum Operator gemacht.`
          break
        case "message":
          successMessage = `Nachricht an ${player} gesendet.`
          break
      }

      toast({
        title: "Aktion erfolgreich",
        description: successMessage,
      })
    }, 500)

    setActionDialog({ open: false, action: null })
  }

  const formatPlayTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60

    if (hours > 0) {
      return `${hours}h ${mins}m`
    }
    return `${mins}m`
  }

  if (!stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Spielerverwaltung</CardTitle>
          <CardDescription>Verwalte Spieler auf dem Server</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">Serverdaten werden geladen...</div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <CardTitle>Spielerverwaltung</CardTitle>
            <CardDescription>Verwalte Spieler auf dem Server</CardDescription>
          </div>
          <div className="relative w-full md:w-auto">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Spieler suchen..."
              className="pl-8 w-full md:w-[250px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {filteredPlayers.length > 0 ? (
          <div className="rounded-md border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Spieler</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>IP-Adresse</TableHead>
                  <TableHead>Spielzeit</TableHead>
                  <TableHead>Letzter Login</TableHead>
                  <TableHead>Aktionen</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredPlayers.map((player) => (
                  <TableRow key={player.name}>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <img
                          src={`https://mc-heads.net/avatar/${player.name}/32`}
                          alt={player.name}
                          className="h-8 w-8 rounded-sm"
                        />
                        <span className="font-medium">{player.name}</span>
                        {player.isOp && (
                          <Badge variant="default" className="ml-1">
                            <Crown className="h-3 w-3 mr-1" />
                            OP
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="bg-green-500/10 text-green-500 border-green-500/20">
                        Online
                      </Badge>
                    </TableCell>
                    <TableCell>{player.ip}</TableCell>
                    <TableCell>{formatPlayTime(player.playTime)}</TableCell>
                    <TableCell>{player.lastLogin.toLocaleString()}</TableCell>
                    <TableCell>
                      <div className="flex space-x-1">
                        <Button variant="outline" size="sm" onClick={() => handleAction("message", player.name)}>
                          <MessageSquare className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleAction("kick", player.name)}>
                          <UserMinus className="h-3.5 w-3.5" />
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => handleAction("ban", player.name)}>
                          <Ban className="h-3.5 w-3.5" />
                        </Button>
                        {!player.isOp && (
                          <Button variant="outline" size="sm" onClick={() => handleAction("op", player.name)}>
                            <Shield className="h-3.5 w-3.5" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-muted-foreground">
              {searchQuery ? "Keine Spieler gefunden, die deiner Suche entsprechen." : "Keine Spieler online."}
            </p>
          </div>
        )}
      </CardContent>

      {/* Action Dialog */}
      <Dialog open={actionDialog.open} onOpenChange={(open) => setActionDialog({ ...actionDialog, open })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {actionDialog.action?.type === "kick" && "Spieler kicken"}
              {actionDialog.action?.type === "ban" && "Spieler bannen"}
              {actionDialog.action?.type === "op" && "Spieler zum OP machen"}
              {actionDialog.action?.type === "message" && "Nachricht an Spieler senden"}
            </DialogTitle>
            <DialogDescription>Spieler: {actionDialog.action?.player}</DialogDescription>
          </DialogHeader>

          {(actionDialog.action?.type === "kick" || actionDialog.action?.type === "ban") && (
            <div className="py-4">
              <label className="text-sm font-medium">Grund</label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Grund für die Aktion eingeben..."
                className="mt-1"
              />
            </div>
          )}

          {actionDialog.action?.type === "message" && (
            <div className="py-4">
              <label className="text-sm font-medium">Nachricht</label>
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Nachricht an den Spieler..."
                className="mt-1"
              />
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setActionDialog({ open: false, action: null })}>
              Abbrechen
            </Button>
            <Button onClick={executeAction} variant={actionDialog.action?.type === "ban" ? "destructive" : "default"}>
              Ausführen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  )
}

