"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { StatusIndicator } from "@/components/status-indicator"
import { AlertCircle, Server, Users, Clock, RefreshCw } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { useServerData } from "@/components/server-data-provider"
import { Badge } from "@/components/ui/badge"
import { useState } from "react"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

interface ServerStatusProps {
  serverAddress?: string
  showPlayerList?: boolean
}

// Aktualisiere die ServerStatus-Komponente, um die OPInsel.de-Daten zu verwenden
export function ServerStatus({ serverAddress = "OPInsel.de", showPlayerList = false }: ServerStatusProps) {
  const { stats, loading, error, refreshData } = useServerData()
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = async () => {
    setIsRefreshing(true)
    await refreshData()
    setTimeout(() => setIsRefreshing(false), 500) // Zeige den Lade-Effekt für mindestens 500ms
  }

  const formatUptime = (seconds: number): string => {
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)

    return `${days}d ${hours}h ${minutes}m`
  }

  if (loading && !stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Server Status</CardTitle>
          <CardDescription>Lädt Serverdaten...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center py-6">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  if (error || !stats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Server Status</CardTitle>
          <CardDescription>Status von {serverAddress}</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Fehler</AlertTitle>
            <AlertDescription>{error || "Serverdaten konnten nicht abgerufen werden"}</AlertDescription>
          </Alert>
          <div className="mt-4 flex justify-center">
            <Button onClick={handleRefresh} disabled={isRefreshing}>
              {isRefreshing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Aktualisiere...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Erneut versuchen
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  // Aktualisiere die Anzeige für den Fall, dass der Server offline ist
  if (!stats.online) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Server Status</CardTitle>
          <CardDescription>Status von {serverAddress}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Status:</span>
            <StatusIndicator status={false} activeText="Online" inactiveText="Offline" />
          </div>

          <div className="text-center py-6 mt-4">
            <AlertCircle className="mx-auto h-8 w-8 text-destructive opacity-80" />
            <p className="mt-2 text-sm text-muted-foreground">Der Server ist derzeit offline oder nicht erreichbar.</p>
            <Button onClick={handleRefresh} variant="outline" size="sm" className="mt-4" disabled={isRefreshing}>
              {isRefreshing ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  Aktualisiere...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Erneut versuchen
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <div>
          <CardTitle className="flex items-center">
            <Server className="mr-2 h-5 w-5" />
            Server Status
          </CardTitle>
          <CardDescription>Status von {serverAddress}</CardDescription>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing}>
          {isRefreshing ? <RefreshCw className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium">Status:</span>
          <StatusIndicator status={stats.online} activeText="Online" inactiveText="Offline" />
        </div>

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">Spieler:</span>
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-1 text-muted-foreground" />
              <span>
                {stats.players.online}/{stats.players.max}
              </span>
            </div>
          </div>
          <Progress value={(stats.players.online / stats.players.max) * 100} className="h-2" />
        </div>

        {showPlayerList && stats.players.list.length > 0 && (
          <div className="space-y-2">
            <span className="text-sm font-medium">Online Spieler:</span>
            <div className="flex flex-wrap gap-1">
              {stats.players.list.map((player) => (
                <TooltipProvider key={player}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="relative group">
                        <img
                          src={`https://mc-heads.net/avatar/${player}/32`}
                          alt={player}
                          className="h-8 w-8 rounded-sm hover:scale-110 transition-transform"
                        />
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>{player}</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              ))}
              {stats.players.list.length > 10 && (
                <Badge variant="secondary" className="h-8 flex items-center">
                  +{stats.players.list.length - 10} weitere
                </Badge>
              )}
            </div>
          </div>
        )}

        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm font-medium">RAM-Nutzung:</span>
            <span>
              {Math.round((stats.memoryUsage / 1024) * 10) / 10}GB / {stats.memoryMax / 1024}GB
            </span>
          </div>
          <Progress value={(stats.memoryUsage / stats.memoryMax) * 100} className="h-2" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <span className="text-sm font-medium block">TPS:</span>
            <span
              className={`text-lg ${stats.tps >= 19 ? "text-green-600" : stats.tps >= 15 ? "text-yellow-500" : "text-red-500"}`}
            >
              {stats.tps.toFixed(1)}
            </span>
          </div>

          <div>
            <span className="text-sm font-medium block">Version:</span>
            <span className="text-lg">{stats.version}</span>
          </div>

          <div>
            <span className="text-sm font-medium block">Uptime:</span>
            <div className="flex items-center">
              <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
              <span>{formatUptime(stats.uptime)}</span>
            </div>
          </div>

          <div>
            <span className="text-sm font-medium block">Letztes Update:</span>
            <span className="text-sm text-muted-foreground">{stats.lastUpdated.toLocaleTimeString()}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

