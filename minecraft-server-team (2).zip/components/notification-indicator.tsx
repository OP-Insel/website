"use client"

import { useEffect, useState } from "react"
import { Bell } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

interface Notification {
  id: string
  userId: string
  type: string
  message: string
  timestamp: string
  read: boolean
}

export function NotificationIndicator() {
  const [unreadCount, setUnreadCount] = useState(0)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in
    const currentUser = localStorage.getItem("currentUser")
    if (!currentUser) return

    const userData = JSON.parse(currentUser)
    setUser(userData)

    // Get notifications for this user
    const checkNotifications = () => {
      const allNotifications = JSON.parse(localStorage.getItem("notifications") || "[]")
      const userNotifications = allNotifications.filter((n: Notification) => n.userId === userData.id && !n.read)
      setUnreadCount(userNotifications.length)
    }

    // Check initially
    checkNotifications()

    // Set up interval to check periodically
    const interval = setInterval(checkNotifications, 10000) // Check every 10 seconds

    return () => clearInterval(interval)
  }, [])

  if (!user || unreadCount === 0) {
    return null
  }

  return (
    <Button variant="ghost" size="sm" className="relative" onClick={() => router.push("/notifications")}>
      <Bell className="h-5 w-5" />
      <Badge className="absolute -top-1 -right-1 px-1.5 py-0.5 min-w-[1.25rem] min-h-[1.25rem] flex items-center justify-center">
        {unreadCount}
      </Badge>
      <span className="sr-only">Benachrichtigungen</span>
    </Button>
  )
}

