"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { PointsDisplay } from "@/components/points-display"
import { StatusIndicator } from "@/components/status-indicator"
import { MoreHorizontal, Edit, Trash, Ban, CheckCircle, Shield, TrendingDown } from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"

interface UserCardProps {
  user: any
  currentUser: any
  roles: any[]
  violations: any[]
  onEdit: (userId: string) => void
  onDelete: (userId: string) => void
  onApprove: (userId: string, approved: boolean) => void
  onRoleChange: (userId: string, newRole: string) => void
  onPermissionEdit: (userId: string) => void
  onPointDeduction: (userId: string, points: number, reason: string) => void
}

export function UserCard({
  user,
  currentUser,
  roles,
  violations,
  onEdit,
  onDelete,
  onApprove,
  onRoleChange,
  onPermissionEdit,
  onPointDeduction,
}: UserCardProps) {
  const { toast } = useToast()
  const [pointDeductionDialog, setPointDeductionDialog] = useState(false)
  const [selectedViolation, setSelectedViolation] = useState("")
  const [customReason, setCustomReason] = useState("")
  const [pointsToDeduct, setPointsToDeduct] = useState(0)

  const canEditUsers =
    currentUser.role === "owner" ||
    currentUser.role === "co-owner" ||
    (currentUser.permissions && currentUser.permissions.includes("manage_users"))

  const canManagePoints =
    currentUser.role === "owner" ||
    currentUser.role === "co-owner" ||
    (currentUser.permissions && currentUser.permissions.includes("manage_points"))

  const handlePointDeductionSubmit = () => {
    if (selectedViolation === "custom" && (!customReason || pointsToDeduct <= 0)) {
      toast({
        title: "Fehler",
        description: "Bitte gib einen Grund und eine gültige Punktzahl an.",
        variant: "destructive",
      })
      return
    }

    if (selectedViolation !== "custom" && !selectedViolation) {
      toast({
        title: "Fehler",
        description: "Bitte wähle einen Regelverstoß aus.",
        variant: "destructive",
      })
      return
    }

    const reason =
      selectedViolation === "custom" ? customReason : violations.find((v) => v.id === selectedViolation)?.name || ""

    const points =
      selectedViolation === "custom"
        ? pointsToDeduct
        : violations.find((v) => v.id === selectedViolation)?.pointsDeduction || 0

    onPointDeduction(user.id, points, reason)
    setPointDeductionDialog(false)
    setSelectedViolation("")
    setCustomReason("")
    setPointsToDeduct(0)
  }

  return (
    <>
      <Card className={`p-4 ${!user.approved ? "bg-red-50 dark:bg-red-950/20" : ""}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="h-12 w-12 rounded-md overflow-hidden">
              <img
                src={`https://mc-heads.net/avatar/${user.username}/64`}
                alt={user.username}
                className="h-full w-full object-cover"
                onError={(e) => {
                  e.currentTarget.src = `https://mc-heads.net/avatar/MHF_Steve/64`
                }}
              />
            </div>
            <div>
              <h3 className="font-medium">{user.username}</h3>
              <PointsDisplay points={user.points || 0} size="sm" />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Badge variant="outline">{roles.find((r) => r.id === user.role)?.name || user.role}</Badge>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>Benutzeraktionen</DropdownMenuLabel>

                <DropdownMenuSeparator />

                <DropdownMenuItem onClick={() => setPointDeductionDialog(true)} className="cursor-pointer">
                  <TrendingDown className="mr-2 h-4 w-4" />
                  Punktabzug vorschlagen
                </DropdownMenuItem>

                {canEditUsers && (
                  <>
                    <DropdownMenuSeparator />

                    <DropdownMenuItem onClick={() => onEdit(user.id)} className="cursor-pointer">
                      <Edit className="mr-2 h-4 w-4" />
                      Bearbeiten
                    </DropdownMenuItem>

                    <DropdownMenuItem onClick={() => onPermissionEdit(user.id)} className="cursor-pointer">
                      <Shield className="mr-2 h-4 w-4" />
                      Berechtigungen
                    </DropdownMenuItem>

                    {!user.approved ? (
                      <DropdownMenuItem onClick={() => onApprove(user.id, true)} className="cursor-pointer">
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Freigeben
                      </DropdownMenuItem>
                    ) : (
                      <>
                        <DropdownMenuItem
                          onClick={() => onApprove(user.id, false)}
                          className="cursor-pointer text-amber-600 dark:text-amber-400"
                        >
                          <Ban className="mr-2 h-4 w-4" />
                          Freigabe entziehen
                        </DropdownMenuItem>

                        <DropdownMenuItem
                          onClick={() => onDelete(user.id)}
                          className="cursor-pointer text-red-600 dark:text-red-400"
                          disabled={user.role === "owner"}
                        >
                          <Trash className="mr-2 h-4 w-4" />
                          Löschen
                        </DropdownMenuItem>
                      </>
                    )}
                  </>
                )}

                <DropdownMenuSeparator />

                <div className="p-2">
                  <div className="space-y-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status:</span>
                      <StatusIndicator
                        status={!user.banned}
                        activeText="Aktiv"
                        inactiveText="Gesperrt"
                        className="text-xs"
                      />
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Freigabe:</span>
                      <StatusIndicator status={user.approved} activeText="Ja" inactiveText="Nein" className="text-xs" />
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Registriert:</span>
                      <span>{new Date(user.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </Card>

      {/* Point Deduction Dialog */}
      <Dialog open={pointDeductionDialog} onOpenChange={setPointDeductionDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Punktabzug für {user.username}</DialogTitle>
            <DialogDescription>
              {canManagePoints
                ? "Als Administrator kannst du direkt Punkte abziehen."
                : "Dein Vorschlag wird von einem Administrator geprüft."}
            </DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label className="text-sm font-medium">Regelverstoß</label>
              <Select
                value={selectedViolation}
                onValueChange={(value) => {
                  setSelectedViolation(value)
                  if (value !== "custom") {
                    const violation = violations.find((v) => v.id === value)
                    if (violation) {
                      setPointsToDeduct(violation.pointsDeduction)
                    }
                  }
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Regelverstoß auswählen" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="custom">Benutzerdefiniert</SelectItem>
                  {violations.map((violation) => (
                    <SelectItem key={violation.id} value={violation.id}>
                      {violation.name} (-{violation.pointsDeduction} Punkte)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedViolation === "custom" && (
              <>
                <div className="grid gap-2">
                  <label className="text-sm font-medium">Grund</label>
                  <Textarea
                    value={customReason}
                    onChange={(e) => setCustomReason(e.target.value)}
                    placeholder="Grund für den Punktabzug"
                  />
                </div>

                <div className="grid gap-2">
                  <label className="text-sm font-medium">Punkte</label>
                  <Input
                    type="number"
                    value={pointsToDeduct}
                    onChange={(e) => setPointsToDeduct(Number.parseInt(e.target.value) || 0)}
                    min="1"
                    placeholder="Anzahl der abzuziehenden Punkte"
                  />
                </div>
              </>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setPointDeductionDialog(false)}>
              Abbrechen
            </Button>
            <Button onClick={handlePointDeductionSubmit}>
              {canManagePoints ? "Punkte abziehen" : "Vorschlag einreichen"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

