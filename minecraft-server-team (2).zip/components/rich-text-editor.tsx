"use client"

import React, { useState, useEffect } from "react"
import {
  Bold,
  Italic,
  List,
  ListOrdered,
  Heading1,
  Heading2,
  Image,
  Link,
  AlignLeft,
  AlignCenter,
  AlignRight,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"

interface RichTextEditorProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  minHeight?: string
}

export function RichTextEditor({
  value,
  onChange,
  placeholder = "Start writing...",
  minHeight = "200px",
}: RichTextEditorProps) {
  const [editorState, setEditorState] = useState(value)
  const [activeTab, setActiveTab] = useState<"write" | "preview">("write")
  const editorRef = React.useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.innerHTML = value
    }
  }, [value])

  const handleEditorChange = () => {
    if (editorRef.current) {
      const newContent = editorRef.current.innerHTML
      setEditorState(newContent)
      onChange(newContent)
    }
  }

  const execCommand = (command: string, value = "") => {
    document.execCommand(command, false, value)
    handleEditorChange()
    editorRef.current?.focus()
  }

  const insertHeading = (level: 1 | 2) => {
    execCommand("formatBlock", `<h${level}>`)
  }

  const insertLink = () => {
    const url = prompt("Enter URL:")
    if (url) {
      execCommand("createLink", url)
    }
  }

  const insertImage = () => {
    const url = prompt("Enter image URL:")
    if (url) {
      execCommand("insertImage", url)
    }
  }

  return (
    <div className="border rounded-md overflow-hidden">
      <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "write" | "preview")}>
        <div className="bg-muted/50 border-b px-2">
          <div className="flex items-center justify-between">
            <TabsList className="h-9 bg-transparent">
              <TabsTrigger value="write" className="text-xs">
                Write
              </TabsTrigger>
              <TabsTrigger value="preview" className="text-xs">
                Preview
              </TabsTrigger>
            </TabsList>

            {activeTab === "write" && (
              <div className="flex items-center space-x-1 overflow-auto py-1">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => execCommand("bold")}
                >
                  <Bold className="h-4 w-4" />
                  <span className="sr-only">Bold</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => execCommand("italic")}
                >
                  <Italic className="h-4 w-4" />
                  <span className="sr-only">Italic</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => insertHeading(1)}
                >
                  <Heading1 className="h-4 w-4" />
                  <span className="sr-only">Heading 1</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => insertHeading(2)}
                >
                  <Heading2 className="h-4 w-4" />
                  <span className="sr-only">Heading 2</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => execCommand("insertUnorderedList")}
                >
                  <List className="h-4 w-4" />
                  <span className="sr-only">Bullet List</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => execCommand("insertOrderedList")}
                >
                  <ListOrdered className="h-4 w-4" />
                  <span className="sr-only">Numbered List</span>
                </Button>
                <Button type="button" variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={insertLink}>
                  <Link className="h-4 w-4" />
                  <span className="sr-only">Insert Link</span>
                </Button>
                <Button type="button" variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={insertImage}>
                  <Image className="h-4 w-4" />
                  <span className="sr-only">Insert Image</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => execCommand("justifyLeft")}
                >
                  <AlignLeft className="h-4 w-4" />
                  <span className="sr-only">Align Left</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => execCommand("justifyCenter")}
                >
                  <AlignCenter className="h-4 w-4" />
                  <span className="sr-only">Align Center</span>
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0"
                  onClick={() => execCommand("justifyRight")}
                >
                  <AlignRight className="h-4 w-4" />
                  <span className="sr-only">Align Right</span>
                </Button>
              </div>
            )}
          </div>
        </div>

        <TabsContent value="write" className="p-0 m-0">
          <div
            ref={editorRef}
            contentEditable
            className="p-3 outline-none"
            style={{ minHeight }}
            onInput={handleEditorChange}
            dangerouslySetInnerHTML={{ __html: value || "" }}
            placeholder={placeholder}
          />
        </TabsContent>

        <TabsContent value="preview" className="p-3 prose prose-sm max-w-none m-0">
          <div dangerouslySetInnerHTML={{ __html: editorState }} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

