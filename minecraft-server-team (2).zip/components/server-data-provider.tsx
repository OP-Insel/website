"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

interface ServerStats {
  online: boolean
  players: {
    online: number
    max: number
    list: string[]
  }
  version: string
  lastUpdated: Date
  tps: number
  memoryUsage: number
  memoryMax: number
  uptime: number
}

interface ServerDataContextType {
  stats: ServerStats | null
  loading: boolean
  error: string | null
  refreshData: () => Promise<void>
}

const ServerDataContext = createContext<ServerDataContextType | undefined>(undefined)

export function useServerData() {
  const context = useContext(ServerDataContext)
  if (context === undefined) {
    throw new Error("useServerData must be used within a ServerDataProvider")
  }
  return context
}

interface ServerDataProviderProps {
  children: ReactNode
}

export function ServerDataProvider({ children }: ServerDataProviderProps) {
  const [stats, setStats] = useState<ServerStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchServerData = async () => {
    try {
      setLoading(true)
      setError(null)

      // Verwende die mcsrvstat.us API, um echte Daten vom Server zu erhalten
      const response = await fetch("https://api.mcsrvstat.us/2/opinsel.de")

      if (!response.ok) {
        throw new Error(`API-Fehler: ${response.status}`)
      }

      const data = await response.json()

      // Überprüfe, ob der Server online ist
      if (!data.online) {
        // Server ist offline
        setStats({
          online: false,
          players: {
            online: 0,
            max: 0,
            list: [],
          },
          version: data.version || "Unbekannt",
          lastUpdated: new Date(),
          tps: 0,
          memoryUsage: 0,
          memoryMax: 0,
          uptime: 0,
        })
        return
      }

      // Server ist online, verarbeite die Daten
      const serverData: ServerStats = {
        online: true,
        players: {
          online: data.players?.online || 0,
          max: data.players?.max || 0,
          list: data.players?.list || [],
        },
        version: data.version || "Unbekannt",
        lastUpdated: new Date(),
        tps: 20, // TPS wird von der API nicht bereitgestellt, daher Standardwert
        memoryUsage: 4096, // Speichernutzung wird nicht bereitgestellt
        memoryMax: 8192, // Maximaler Speicher wird nicht bereitgestellt
        uptime: 86400, // Uptime wird nicht bereitgestellt
      }

      setStats(serverData)
    } catch (err) {
      console.error("Fehler beim Abrufen der Serverdaten:", err)
      setError("Fehler beim Abrufen der Serverdaten. Der Server könnte offline sein.")

      // Setze Offline-Status
      setStats({
        online: false,
        players: {
          online: 0,
          max: 0,
          list: [],
        },
        version: "Unbekannt",
        lastUpdated: new Date(),
        tps: 0,
        memoryUsage: 0,
        memoryMax: 0,
        uptime: 0,
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchServerData()

    // Aktualisiere Daten alle 2 Minuten
    const interval = setInterval(fetchServerData, 2 * 60 * 1000)
    return () => clearInterval(interval)
  }, [])

  return (
    <ServerDataContext.Provider value={{ stats, loading, error, refreshData: fetchServerData }}>
      {children}
    </ServerDataContext.Provider>
  )
}

